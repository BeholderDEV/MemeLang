Integrantes:
Adson Marques da Silva Esteves
Alisson Steffens Henrique
Augusto C. Pluschkat

Dependencias:
J� est�o na pasta Lib

Projeto:
Est� no Github link: (https://github.com/BeholderDEV/MemeLang)